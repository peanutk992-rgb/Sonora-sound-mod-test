# Sonora - mod suara klien untuk Minecraft Java 1.21.11 (Fabric)

Mod **orisinal** yang bikin suara UI dan pertarungan lebih renyah, plus banyak umpan balik suara tambahan.
Konsepnya mirip mod suara kayak Soundify, tapi **semua kode dan suaranya dibuat dari nol**
(suara disintesis sendiri lewat `tools/make_sounds.py`). **Tanpa login, akun, atau lapisan security apa pun.**
Client-only: nggak perlu dipasang di server.

## Fitur

- **UI**: klik tombol, tik saat kursor di tombol, buka/tutup layar, suara mengetik, ambil/taruh item di inventori, ganti slot hotbar
- **Tarung**: gaya baru untuk hit kuat/lemah, critical, knockback, sweep, dan miss
- **Panah**: ding nyaring saat panahmu kena pemain, suara tarik busur, ping saat busur penuh, suara lepas panah
- **Lainnya**: detak jantung saat darah tipis (ambang di config), suara jongkok, suara teredam di bawah air
- **Editor per suara** (semua sound event game): volume, pitch, mute, tes, dan **ganti** dengan sound lain
  atau dengan file `.wav` / `.ogg` milikmu sendiri
- **Pemicu chat**: pola regex di chat memainkan suara pilihanmu
- Bahasa: Inggris dan Indonesia

## Cara build dari HP (lewat GitHub, nggak perlu PC)

1. Buat repo baru di GitHub (private juga boleh).
2. **Add file -> Upload files**, upload `sonora-src.zip` ke root repo.
3. **Add file -> Create new file**, namai `.github/workflows/build.yml`, tempel isi file `build-from-zip.yml`, lalu Commit.
4. Buka tab **Actions** -> workflow **build-from-zip** -> **Run workflow**. Tunggu sekitar 3-6 menit.
5. Buka run yang hijau -> bagian **Artifacts** -> download -> ekstrak -> pakai `sonora-1.0.0.jar`
   (yang `-sources` jangan dipakai).

Di PC: `./gradlew build` (JDK 21+), hasilnya di `build/libs/`.

## Pasang

- Fabric Loader 0.17.3+ untuk 1.21.11 dan **Fabric API** untuk 1.21.11.
- Taruh `sonora-1.0.0.jar` di folder `mods` (Zalith/PojavLauncher: pasang Fabric 1.21.11 lewat launcher,
  lalu taruh jar di folder `mods` milik versi itu).

## Pakai

- Ketik `/sonora` di chat, atau atur tombol **Open Sonora settings** di Pengaturan -> Kontrol (default kosong).
- Config: `config/sonora.json`.
- File suara sendiri: taruh `.wav` (PCM 8/16/24/32-bit atau float) atau `.ogg` di `config/sonora/sounds/`.
  Di editor per suara pilih sound -> tombol `R` -> ketik `file:namafile.wav`.
- Contoh pemicu chat di `config/sonora.json` (nyalakan "Chat triggers" di pengaturan):

```json
"chatRules": [
  { "pattern": "(?i)\\bgg\\b", "sound": "minecraft:entity.experience_orb.pickup", "volume": 1.0, "pitch": 1.0, "stop": false }
]
```

## Catatan jujur

- **Belum pernah dikompilasi.** Sandbox tempat mod ini ditulis nggak bisa akses server Fabric/Mojang/Maven,
  jadi API-nya dicek manual dari mapping Yarn dan source Fabric API. Build pertama bisa saja menemukan
  error kecil; kalau ada, kirim lognya dan tinggal diperbaiki.
- Ini **bukan port atau crack** mod aslinya. Tidak ada kode atau aset dari jar mana pun yang dipakai.
- Suara bawaan adalah suara sintetis buatan sendiri, jadi terdengarnya beda dari mod aslinya.
- Lisensi: CC0 (domain publik).
