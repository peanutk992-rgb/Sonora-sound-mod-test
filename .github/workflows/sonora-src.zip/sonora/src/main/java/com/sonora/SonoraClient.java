package com.sonora;

import com.sonora.config.SonoraConfig;
import com.sonora.gui.SonoraScreen;
import com.sonora.sound.CustomAudio;
import com.sonora.trigger.ChatTriggers;
import com.sonora.trigger.ScreenTriggers;
import com.sonora.trigger.Triggers;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Sonora - a client side sound customisation mod.
 *
 * <p>Open the settings with the {@code /sonora} command, or bind the "Open Sonora settings" key in the
 * controls menu.
 */
public final class SonoraClient implements ClientModInitializer {
    public static final String MOD_ID = "sonora";
    public static final Logger LOGGER = LoggerFactory.getLogger("Sonora");

    private static KeyBinding openKey;
    private static volatile boolean openRequested;

    @Override
    public void onInitializeClient() {
        SonoraConfig.load();
        CustomAudio.ensureFolder();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sonora.open",
                GLFW.GLFW_KEY_UNKNOWN,
                KeyBinding.Category.create(Identifier.of(MOD_ID, "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                openRequested = true;
            }
            // The command is typed in the chat screen, so wait until it has closed.
            if (openRequested && client.currentScreen == null) {
                openRequested = false;
                client.setScreen(new SonoraScreen(null));
            }
            Triggers.tick(client);
        });

        ScreenTriggers.register();
        ChatTriggers.register();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("sonora").executes(context -> {
                    openRequested = true;
                    return 1;
                })));

        LOGGER.info("Sonora loaded. Put your own .wav/.ogg files in {}", CustomAudio.folder());
    }
}
