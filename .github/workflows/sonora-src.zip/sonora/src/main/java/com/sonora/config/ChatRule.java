package com.sonora.config;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Plays a sound when a chat / game message matches a regular expression.
 * Rules live in {@code config/sonora.json} under {@code chatRules}.
 */
public final class ChatRule {
    public String pattern = "";
    /** Sound event id, or {@code file:name.wav}. */
    public String sound = "";
    public float volume = 1.0f;
    public float pitch = 1.0f;
    /** When true, later rules are not checked after this one matched. */
    public boolean stop = false;

    private transient Pattern compiled;
    private transient boolean invalid;

    /** Returns the compiled pattern, or {@code null} when the expression is invalid. */
    public Pattern compiled() {
        if (compiled == null && !invalid) {
            try {
                compiled = Pattern.compile(pattern == null ? "" : pattern);
            } catch (PatternSyntaxException e) {
                invalid = true;
            }
        }
        return compiled;
    }
}
