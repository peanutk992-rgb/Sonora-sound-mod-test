package com.sonora.config;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.sonora.SonoraClient;
import net.fabricmc.loader.api.FabricLoader;

/** All settings of the mod, stored as pretty JSON in {@code config/sonora.json}. */
public final class SonoraConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static SonoraConfig instance = new SonoraConfig();

    // ----- general -----
    public boolean enabled = true;
    /** Multiplier for every sound the mod itself plays (UI, bow cues, heartbeat...). */
    public float triggerVolume = 1.0f;

    // ----- style (replace vanilla sounds with the bundled ones) -----
    public boolean uiStyle = true;
    public boolean combatStyle = true;
    public boolean arrowDing = true;

    // ----- extra sounds -----
    public boolean uiHover = false;
    public boolean uiOpenClose = true;
    public boolean uiTyping = true;
    public boolean inventorySounds = true;
    public boolean hotbarSounds = true;
    public boolean bowDraw = true;
    public boolean bowCharged = true;
    public boolean lowHealth = true;
    public float lowHealthThreshold = 6.0f;
    public boolean sneakSound = false;

    // ----- environment -----
    public boolean underwaterMuffle = true;
    public float underwaterVolume = 0.55f;

    // ----- chat -----
    public boolean chatTriggers = true;
    public List<ChatRule> chatRules = new ArrayList<>();

    // ----- per sound event -----
    public Map<String, SoundOverride> sounds = new TreeMap<>();

    private SonoraConfig() {
    }

    public static SonoraConfig get() {
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("sonora.json");
    }

    public static void load() {
        Path path = file();
        if (!Files.isRegularFile(path)) {
            instance = new SonoraConfig();
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            SonoraConfig loaded = GSON.fromJson(reader, SonoraConfig.class);
            instance = loaded == null ? new SonoraConfig() : loaded;
        } catch (IOException | JsonParseException e) {
            SonoraClient.LOGGER.warn("Could not read {} ({}); using defaults and keeping a backup.", path, e.toString());
            try {
                Files.copy(path, path.resolveSibling("sonora.json.bak"), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) {
                // best effort only
            }
            instance = new SonoraConfig();
        }
        instance.sanitize();
    }

    public static void save() {
        Path path = file();
        instance.sanitize();
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                GSON.toJson(instance, writer);
            }
        } catch (IOException e) {
            SonoraClient.LOGGER.warn("Could not save {}: {}", path, e.toString());
        }
    }

    /** Restores every setting (including per sound overrides and chat rules) to the defaults. */
    public static void reset() {
        instance = new SonoraConfig();
        save();
    }

    /** Returns the override for a sound id, creating a default one when it does not exist yet. */
    public SoundOverride edit(String soundId) {
        return sounds.computeIfAbsent(soundId, key -> new SoundOverride());
    }

    /** Drops overrides that equal the defaults so the file stays small. */
    public void prune() {
        sounds.values().removeIf(SoundOverride::isDefault);
    }

    private void sanitize() {
        triggerVolume = clamp(triggerVolume, 0.0f, 2.0f);
        lowHealthThreshold = clamp(lowHealthThreshold, 1.0f, 20.0f);
        underwaterVolume = clamp(underwaterVolume, 0.0f, 1.0f);
        if (sounds == null) {
            sounds = new TreeMap<>();
        }
        if (chatRules == null) {
            chatRules = new ArrayList<>();
        }
        sounds.values().removeIf(o -> o == null);
        for (SoundOverride o : sounds.values()) {
            o.volume = clamp(o.volume, 0.0f, 2.0f);
            o.pitch = clamp(o.pitch, 0.5f, 2.0f);
            if (o.replace == null) {
                o.replace = "";
            }
        }
        chatRules.removeIf(r -> r == null);
    }

    private static float clamp(float value, float min, float max) {
        if (Float.isNaN(value)) {
            return min;
        }
        return Math.max(min, Math.min(max, value));
    }
}
