package com.sonora.config;

/**
 * Per sound event settings chosen by the player.
 *
 * <p>{@link #replace} may be empty (no replacement), a sound event id such as
 * {@code minecraft:block.anvil.land} or {@code sonora:combat.hit_strong}, or
 * {@code file:name.wav} for a file inside {@code config/sonora/sounds}.
 */
public final class SoundOverride {
    public float volume = 1.0f;
    public float pitch = 1.0f;
    public boolean muted = false;
    public String replace = "";

    public boolean isDefault() {
        return !muted
                && volume == 1.0f
                && pitch == 1.0f
                && (replace == null || replace.isBlank());
    }

    public boolean hasReplacement() {
        return replace != null && !replace.isBlank();
    }
}
