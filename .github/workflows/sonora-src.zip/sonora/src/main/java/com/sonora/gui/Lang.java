package com.sonora.gui;

import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

/** Small helper for translatable texts that fall back to English when a key is missing. */
final class Lang {
    private Lang() {
    }

    static MutableText t(String key, String fallback) {
        return Text.translatableWithFallback(key, fallback);
    }

    static MutableText onOff(boolean on) {
        return on ? t("sonora.on", "ON") : t("sonora.off", "OFF");
    }
}
