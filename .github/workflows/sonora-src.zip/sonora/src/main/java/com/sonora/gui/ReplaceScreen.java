package com.sonora.gui;

import java.util.List;

import com.sonora.config.SonoraConfig;
import com.sonora.sound.CustomAudio;
import com.sonora.sound.SonoraSounds;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Pick what plays instead of one sound: another sound id, or {@code file:<name>} from the sounds folder. */
public final class ReplaceScreen extends Screen {
    private final Screen parent;
    private final String soundId;
    private TextFieldWidget field;
    private int fileIndex = -1;
    private Text status = Text.empty();

    public ReplaceScreen(Screen parent, String soundId) {
        super(Lang.t("sonora.replace.title", "Replace sound"));
        this.parent = parent;
        this.soundId = soundId;
    }

    @Override
    protected void init() {
        String keep = field != null ? field.getText() : null;
        int cx = width / 2;

        field = new TextFieldWidget(textRenderer, cx - 150, 76, 300, 20, Lang.t("sonora.replace.field", "Replace with"));
        field.setMaxLength(200);
        field.setPlaceholder(Text.literal("minecraft:block.anvil.land  /  file:my_sound.wav"));
        if (keep != null) {
            field.setText(keep);
        } else {
            var current = SonoraConfig.get().sounds.get(soundId);
            field.setText(current == null || current.replace == null ? "" : current.replace);
        }
        addDrawableChild(field);
        setInitialFocus(field);

        addDrawableChild(ButtonWidget.builder(Lang.t("sonora.replace.pick", "Next file from folder"), button -> pickFile())
                .dimensions(cx - 150, 102, 148, 20).build());
        addDrawableChild(ButtonWidget.builder(Lang.t("sonora.replace.clear", "Clear"), button -> field.setText(""))
                .dimensions(cx + 2, 102, 148, 20).build());
        addDrawableChild(ButtonWidget.builder(Lang.t("sonora.replace.test", "Test"), button -> test())
                .dimensions(cx - 150, 128, 148, 20).build());
        addDrawableChild(ButtonWidget.builder(Lang.t("gui.done", "Done"), button -> close())
                .dimensions(cx + 2, 128, 148, 20).build());
    }

    private void pickFile() {
        List<String> files = CustomAudio.listFiles();
        if (files.isEmpty()) {
            status = Lang.t("sonora.replace.nofiles", "No .wav/.ogg files in the folder yet.");
            return;
        }
        fileIndex = (fileIndex + 1) % files.size();
        field.setText("file:" + files.get(fileIndex));
        status = Text.literal(files.get(fileIndex));
    }

    private void applyToConfig() {
        SonoraConfig.get().edit(soundId).replace = field.getText().trim();
    }

    private void test() {
        applyToConfig();
        SonoraSounds.playTarget(soundId, 1.0f, 1.0f);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = width / 2;
        context.drawCenteredTextWithShadow(textRenderer, getTitle(), cx, 10, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(soundId), cx, 24, 0xFFFFFF55);
        context.drawCenteredTextWithShadow(textRenderer,
                Lang.t("sonora.replace.help1", "Type a sound id, or file:<name> for your own file."), cx, 40, 0xFFAAAAAA);
        context.drawCenteredTextWithShadow(textRenderer,
                Lang.t("sonora.replace.help2", "Put .wav or .ogg files in:"), cx, 52, 0xFFAAAAAA);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(textRenderer.trimToWidth(CustomAudio.folder().toString(), width - 20)), cx, 64, 0xFF88CCFF);
        context.drawCenteredTextWithShadow(textRenderer, status, cx, 156, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        applyToConfig();
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
