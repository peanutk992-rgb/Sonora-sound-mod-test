package com.sonora.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

import com.sonora.config.SonoraConfig;
import com.sonora.sound.CustomAudio;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

/** Main settings screen: a paged grid of toggles and sliders that adapts to the window size. */
public final class SonoraScreen extends Screen {
    @FunctionalInterface
    private interface Entry {
        ClickableWidget create(int x, int y, int width);
    }

    private final Screen parent;
    private final List<Entry> entries = new ArrayList<>();
    private int page;
    private int pageCount = 1;

    public SonoraScreen(Screen parent) {
        super(Lang.t("sonora.title", "Sonora - Sound Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        buildEntries();

        int columns = width >= 340 ? 2 : 1;
        int gap = 8;
        int columnWidth = Math.min(200, (width - 16 - (columns - 1) * gap) / columns);
        int gridWidth = columns * columnWidth + (columns - 1) * gap;
        int left = (width - gridWidth) / 2;
        int top = 32;
        int rowHeight = 24;
        int rows = Math.max(1, (height - 36 - top) / rowHeight);
        int perPage = rows * columns;
        pageCount = Math.max(1, (entries.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pageCount - 1));

        int start = page * perPage;
        for (int i = 0; i < perPage && start + i < entries.size(); i++) {
            int column = i / rows;
            int row = i % rows;
            int x = left + column * (columnWidth + gap);
            int y = top + row * rowHeight;
            addDrawableChild(entries.get(start + i).create(x, y, columnWidth));
        }

        int navY = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), button -> changePage(-1))
                .dimensions(width / 2 - 100, navY, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Lang.t("gui.done", "Done"), button -> close())
                .dimensions(width / 2 - 66, navY, 132, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), button -> changePage(1))
                .dimensions(width / 2 + 70, navY, 30, 20).build());
    }

    private void changePage(int delta) {
        page = Math.max(0, Math.min(pageCount - 1, page + delta));
        clearAndInit();
    }

    private void buildEntries() {
        entries.clear();
        entries.add(toggle("sonora.opt.enabled", "Mod enabled",
                () -> SonoraConfig.get().enabled, v -> SonoraConfig.get().enabled = v));
        entries.add(slider("sonora.opt.triggerVolume", "Extra sounds volume", 0.0, 2.0,
                () -> SonoraConfig.get().triggerVolume, v -> SonoraConfig.get().triggerVolume = (float) v));
        entries.add(toggle("sonora.opt.uiStyle", "Button click style",
                () -> SonoraConfig.get().uiStyle, v -> SonoraConfig.get().uiStyle = v));
        entries.add(toggle("sonora.opt.combatStyle", "Combat sound style",
                () -> SonoraConfig.get().combatStyle, v -> SonoraConfig.get().combatStyle = v));
        entries.add(toggle("sonora.opt.arrowDing", "Arrow hit ding",
                () -> SonoraConfig.get().arrowDing, v -> SonoraConfig.get().arrowDing = v));
        entries.add(toggle("sonora.opt.uiHover", "Button hover tick",
                () -> SonoraConfig.get().uiHover, v -> SonoraConfig.get().uiHover = v));
        entries.add(toggle("sonora.opt.uiOpenClose", "Screen open/close",
                () -> SonoraConfig.get().uiOpenClose, v -> SonoraConfig.get().uiOpenClose = v));
        entries.add(toggle("sonora.opt.uiTyping", "Typing sounds",
                () -> SonoraConfig.get().uiTyping, v -> SonoraConfig.get().uiTyping = v));
        entries.add(toggle("sonora.opt.inventory", "Inventory pick/place",
                () -> SonoraConfig.get().inventorySounds, v -> SonoraConfig.get().inventorySounds = v));
        entries.add(toggle("sonora.opt.hotbar", "Hotbar scroll sound",
                () -> SonoraConfig.get().hotbarSounds, v -> SonoraConfig.get().hotbarSounds = v));
        entries.add(toggle("sonora.opt.bowDraw", "Bow draw cue",
                () -> SonoraConfig.get().bowDraw, v -> SonoraConfig.get().bowDraw = v));
        entries.add(toggle("sonora.opt.bowCharged", "Bow fully drawn ping",
                () -> SonoraConfig.get().bowCharged, v -> SonoraConfig.get().bowCharged = v));
        entries.add(toggle("sonora.opt.lowHealth", "Low health heartbeat",
                () -> SonoraConfig.get().lowHealth, v -> SonoraConfig.get().lowHealth = v));
        entries.add(toggle("sonora.opt.sneak", "Sneak sound",
                () -> SonoraConfig.get().sneakSound, v -> SonoraConfig.get().sneakSound = v));
        entries.add(toggle("sonora.opt.underwater", "Underwater muffling",
                () -> SonoraConfig.get().underwaterMuffle, v -> SonoraConfig.get().underwaterMuffle = v));
        entries.add(slider("sonora.opt.underwaterVolume", "Underwater level", 0.0, 1.0,
                () -> SonoraConfig.get().underwaterVolume, v -> SonoraConfig.get().underwaterVolume = (float) v));
        entries.add(toggle("sonora.opt.chat", "Chat triggers",
                () -> SonoraConfig.get().chatTriggers, v -> SonoraConfig.get().chatTriggers = v));
        entries.add(action("sonora.opt.editor", "Per-sound editor...",
                () -> client.setScreen(new SoundListScreen(this))));
        entries.add(action("sonora.opt.reload", "Reload custom files", () -> {
            CustomAudio.clearCache();
            CustomAudio.ensureFolder();
        }));
        entries.add(action("sonora.opt.reset", "Reset everything", () -> {
            SonoraConfig.reset();
            clearAndInit();
        }));
    }

    private static Entry toggle(String key, String fallback, BooleanSupplier getter, Consumer<Boolean> setter) {
        return (x, y, width) -> ButtonWidget.builder(label(key, fallback, getter.getAsBoolean()), button -> {
            setter.accept(!getter.getAsBoolean());
            button.setMessage(label(key, fallback, getter.getAsBoolean()));
        }).dimensions(x, y, width, 20).build();
    }

    private static Entry slider(String key, String fallback, double min, double max,
            DoubleSupplier getter, DoubleConsumer setter) {
        return (x, y, width) -> new ValueSlider(x, y, width, 20, key, fallback, min, max, getter.getAsDouble(), setter);
    }

    private static Entry action(String key, String fallback, Runnable action) {
        return (x, y, width) -> ButtonWidget.builder(Lang.t(key, fallback), button -> action.run())
                .dimensions(x, y, width, 20).build();
    }

    private static Text label(String key, String fallback, boolean on) {
        return Lang.t(key, fallback).append(Text.literal(": ")).append(Lang.onOff(on));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, getTitle(), width / 2, 12, 0xFFFFFFFF);
        String pageText = (page + 1) + " / " + pageCount;
        context.drawTextWithShadow(textRenderer, pageText, width - 8 - textRenderer.getWidth(pageText), 12, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public void removed() {
        SonoraConfig.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
