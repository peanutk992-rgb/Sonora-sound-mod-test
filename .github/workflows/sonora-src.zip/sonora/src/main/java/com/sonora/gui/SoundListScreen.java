package com.sonora.gui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import com.sonora.config.SonoraConfig;
import com.sonora.config.SoundOverride;
import com.sonora.sound.SonoraSounds;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;

/**
 * Lists every sound event of the game with a search box. For each one you can change the volume and
 * pitch, mute it, preview it, or open the replace screen.
 */
public final class SoundListScreen extends Screen {
    private record RowLabel(String id, int x, int y, int width) {
    }

    private final Screen parent;
    private final List<String> all = new ArrayList<>();
    private final List<ClickableWidget> rowWidgets = new ArrayList<>();
    private final List<RowLabel> labels = new ArrayList<>();
    private List<String> filtered = new ArrayList<>();
    private TextFieldWidget search;
    private String filter = "";
    private int page;
    private int pageCount = 1;

    public SoundListScreen(Screen parent) {
        super(Lang.t("sonora.editor.title", "Per-sound settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (all.isEmpty()) {
            Registries.SOUND_EVENT.getIds().forEach(id -> all.add(id.toString()));
            Collections.sort(all);
        }
        rowWidgets.clear();
        labels.clear();

        search = new TextFieldWidget(textRenderer, width / 2 - 100, 24, 200, 18, Lang.t("sonora.search", "Search"));
        search.setPlaceholder(Lang.t("sonora.search", "Search"));
        search.setText(filter);
        search.setChangedListener(text -> {
            filter = text;
            page = 0;
            refreshRows();
        });
        addDrawableChild(search);
        setInitialFocus(search);

        int navY = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), button -> changePage(-1))
                .dimensions(width / 2 - 100, navY, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Lang.t("gui.done", "Done"), button -> close())
                .dimensions(width / 2 - 66, navY, 132, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), button -> changePage(1))
                .dimensions(width / 2 + 70, navY, 30, 20).build());

        refreshRows();
    }

    private void changePage(int delta) {
        page = Math.max(0, Math.min(pageCount - 1, page + delta));
        refreshRows();
    }

    private void track(ClickableWidget widget) {
        rowWidgets.add(widget);
        addDrawableChild(widget);
    }

    private void refreshRows() {
        for (ClickableWidget widget : rowWidgets) {
            remove(widget);
        }
        rowWidgets.clear();
        labels.clear();

        String needle = filter.trim().toLowerCase(Locale.ROOT);
        filtered = all.stream().filter(id -> matches(id, needle)).collect(Collectors.toList());

        int top = 50;
        int rowHeight = 22;
        int rowsPerPage = Math.max(1, (height - 36 - top) / rowHeight);
        pageCount = Math.max(1, (filtered.size() + rowsPerPage - 1) / rowsPerPage);
        page = Math.max(0, Math.min(page, pageCount - 1));

        int usable = Math.min(width - 12, 500);
        int left = (width - usable) / 2;
        int labelWidth = Math.max(70, usable * 34 / 100);
        int sliderWidth = Math.max(52, (usable - labelWidth - 3 * 20 - 5 * 2) / 2);

        int start = page * rowsPerPage;
        for (int i = 0; i < rowsPerPage && start + i < filtered.size(); i++) {
            String id = filtered.get(start + i);
            int y = top + i * rowHeight;
            labels.add(new RowLabel(id, left, y + 6, labelWidth));

            SoundOverride current = SonoraConfig.get().sounds.get(id);
            double volume = current == null ? 1.0 : current.volume;
            double pitch = current == null ? 1.0 : current.pitch;
            boolean muted = current != null && current.muted;
            boolean replaced = current != null && current.hasReplacement();

            int x = left + labelWidth + 2;
            track(new ValueSlider(x, y, sliderWidth, 20, "sonora.vol", "Vol", 0.0, 2.0, volume,
                    v -> SonoraConfig.get().edit(id).volume = (float) v));
            x += sliderWidth + 2;
            track(new ValueSlider(x, y, sliderWidth, 20, "sonora.pitch", "Pitch", 0.5, 2.0, pitch,
                    v -> SonoraConfig.get().edit(id).pitch = (float) v));
            x += sliderWidth + 2;
            track(ButtonWidget.builder(muteLabel(muted), button -> {
                SoundOverride override = SonoraConfig.get().edit(id);
                override.muted = !override.muted;
                button.setMessage(muteLabel(override.muted));
            }).dimensions(x, y, 20, 20).build());
            x += 22;
            track(ButtonWidget.builder(Text.literal(">"), button -> SonoraSounds.playTarget(id, 1.0f, 1.0f))
                    .dimensions(x, y, 20, 20).build());
            x += 22;
            track(ButtonWidget.builder(Text.literal(replaced ? "§aR" : "R"),
                    button -> client.setScreen(new ReplaceScreen(this, id)))
                    .dimensions(x, y, 20, 20).build());
        }
    }

    private static Text muteLabel(boolean muted) {
        return Text.literal(muted ? "§cM" : "M");
    }

    private static boolean matches(String id, String needle) {
        if (needle.isEmpty()) {
            return true;
        }
        for (String token : needle.split("\\s+")) {
            if (!id.contains(token)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, getTitle(), width / 2, 8, 0xFFFFFFFF);
        String pageText = (page + 1) + " / " + pageCount + "  (" + filtered.size() + ")";
        context.drawTextWithShadow(textRenderer, pageText, width - 8 - textRenderer.getWidth(pageText), 8, 0xFFAAAAAA);
        for (RowLabel label : labels) {
            SoundOverride override = SonoraConfig.get().sounds.get(label.id());
            int color = override == null || override.isDefault() ? 0xFFDDDDDD : 0xFFFFFF55;
            String shown = label.id().startsWith("minecraft:") ? label.id().substring("minecraft:".length()) : label.id();
            context.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(shown, label.width()), label.x(), label.y(), color);
        }
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public void removed() {
        SonoraConfig.get().prune();
        SonoraConfig.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
