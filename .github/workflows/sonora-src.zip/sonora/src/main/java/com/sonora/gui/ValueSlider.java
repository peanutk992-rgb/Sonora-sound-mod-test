package com.sonora.gui;

import java.util.function.DoubleConsumer;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/** A vanilla slider that maps 0..1 onto [min, max] and shows the result as a percentage. */
final class ValueSlider extends SliderWidget {
    private final String key;
    private final String fallback;
    private final double min;
    private final double max;
    private final DoubleConsumer onChange;

    ValueSlider(int x, int y, int width, int height, String key, String fallback,
            double min, double max, double current, DoubleConsumer onChange) {
        super(x, y, width, height, Text.empty(), Math.max(0.0, Math.min(1.0, (current - min) / (max - min))));
        this.key = key;
        this.fallback = fallback;
        this.min = min;
        this.max = max;
        this.onChange = onChange;
        updateMessage();
    }

    private double actual() {
        return min + value * (max - min);
    }

    @Override
    protected void updateMessage() {
        if (key == null) {
            return; // the super constructor may call this before our fields are set
        }
        setMessage(Lang.t(key, fallback).append(Text.literal(": " + Math.round(actual() * 100.0) + "%")));
    }

    @Override
    protected void applyValue() {
        onChange.accept(actual());
    }
}
