package com.sonora.mixin;

import com.sonora.SonoraClient;
import com.sonora.sound.SoundRewrite;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * The only place where Sonora touches the game's sound engine. Every sound goes through
 * {@code SoundSystem#play}, and its volume / pitch are decided by the two {@code getAdjusted*} methods.
 */
@Mixin(SoundSystem.class)
public abstract class SoundSystemMixin {

    /** Lets {@link SoundRewrite} swap the sound that is about to start. */
    @ModifyVariable(
            method = "play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;",
            at = @At("HEAD"),
            argsOnly = true)
    private SoundInstance sonora$rewrite(SoundInstance sound) {
        try {
            return SoundRewrite.rewrite(sound);
        } catch (RuntimeException e) {
            SonoraClient.LOGGER.warn("Sonora could not rewrite a sound: {}", e.toString());
            return sound;
        }
    }

    @Inject(
            method = "getAdjustedVolume(Lnet/minecraft/client/sound/SoundInstance;)F",
            at = @At("RETURN"),
            cancellable = true)
    private void sonora$volume(SoundInstance sound, CallbackInfoReturnable<Float> cir) {
        float multiplier = SoundRewrite.volumeMultiplier(sound);
        if (multiplier != 1.0f) {
            cir.setReturnValue(Math.max(0.0f, cir.getReturnValueF() * multiplier));
        }
    }

    @Inject(
            method = "getAdjustedPitch(Lnet/minecraft/client/sound/SoundInstance;)F",
            at = @At("RETURN"),
            cancellable = true)
    private void sonora$pitch(SoundInstance sound, CallbackInfoReturnable<Float> cir) {
        float multiplier = SoundRewrite.pitchMultiplier(sound);
        if (multiplier != 1.0f) {
            cir.setReturnValue(Math.max(0.5f, Math.min(2.0f, cir.getReturnValueF() * multiplier)));
        }
    }
}
