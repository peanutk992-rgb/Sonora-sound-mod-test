package com.sonora.sound;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.sound.sampled.AudioFormat;

import com.sonora.SonoraClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.sound.OggAudioStream;

/**
 * Loads the player's own sound files from {@code config/sonora/sounds}.
 * Supported: WAV (PCM 8/16/24/32 bit and 32/64 bit float) and OGG Vorbis.
 * Everything is converted to 16-bit mono so it can be positioned in the world.
 */
public final class CustomAudio {
    private static final long MAX_PCM_BYTES = 48L * 1024L * 1024L;
    private static final Map<String, Cached> CACHE = new HashMap<>();

    private record Cached(long modified, PcmClip clip) {
    }

    private CustomAudio() {
    }

    public static Path folder() {
        return FabricLoader.getInstance().getConfigDir().resolve("sonora").resolve("sounds");
    }

    public static void ensureFolder() {
        try {
            Files.createDirectories(folder());
        } catch (IOException e) {
            SonoraClient.LOGGER.warn("Could not create {}: {}", folder(), e.toString());
        }
    }

    /** File names (not paths) of every supported sound in the folder, sorted. */
    public static List<String> listFiles() {
        try (Stream<Path> files = Files.list(folder())) {
            return files.filter(Files::isRegularFile)
                    .map(path -> path.getFileName().toString())
                    .filter(name -> {
                        String lower = name.toLowerCase(Locale.ROOT);
                        return lower.endsWith(".wav") || lower.endsWith(".ogg");
                    })
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            return List.of();
        }
    }

    public static boolean exists(String name) {
        return resolve(name) != null;
    }

    public static synchronized void clearCache() {
        CACHE.clear();
    }

    /** Decodes (and caches) a file. Returns {@code null} when it is missing or cannot be decoded. */
    public static synchronized PcmClip load(String name) {
        Path path = resolve(name);
        if (path == null) {
            return null;
        }
        try {
            long modified = Files.getLastModifiedTime(path).toMillis();
            Cached cached = CACHE.get(name);
            if (cached != null && cached.modified() == modified) {
                return cached.clip();
            }
            PcmClip clip = decode(path);
            CACHE.put(name, new Cached(modified, clip));
            return clip;
        } catch (IOException | RuntimeException e) {
            SonoraClient.LOGGER.warn("Could not decode custom sound {}: {}", name, e.toString());
            return null;
        }
    }

    private static Path resolve(String name) {
        if (name == null || name.isBlank() || name.contains("/") || name.contains("\\") || name.contains("..")) {
            return null;
        }
        Path root = folder().normalize();
        Path path = root.resolve(name).normalize();
        return path.startsWith(root) && Files.isRegularFile(path) ? path : null;
    }

    private static PcmClip decode(Path path) throws IOException {
        String lower = path.getFileName().toString().toLowerCase(Locale.ROOT);
        if (lower.endsWith(".wav")) {
            if (Files.size(path) > MAX_PCM_BYTES) {
                throw new IOException("file is too large");
            }
            return decodeWav(Files.readAllBytes(path));
        }
        if (lower.endsWith(".ogg")) {
            return decodeOgg(path);
        }
        throw new IOException("unsupported file type");
    }

    // ---------------------------------------------------------------- OGG

    private static PcmClip decodeOgg(Path path) throws IOException {
        try (InputStream in = new BufferedInputStream(Files.newInputStream(path));
                OggAudioStream ogg = new OggAudioStream(in)) {
            AudioFormat format = ogg.getFormat();
            int channels = format.getChannels();
            int rate = Math.round(format.getSampleRate());
            ByteArrayOutputStream raw = new ByteArrayOutputStream();
            ByteBuffer chunk = ogg.read(1 << 16);
            while (chunk.hasRemaining()) {
                byte[] bytes = new byte[chunk.remaining()];
                chunk.get(bytes);
                raw.write(bytes);
                if (raw.size() > MAX_PCM_BYTES) {
                    throw new IOException("sound is too long");
                }
                chunk = ogg.read(1 << 16);
            }
            return new PcmClip(downmix(raw.toByteArray(), channels), rate);
        }
    }

    private static byte[] downmix(byte[] pcm16, int channels) {
        if (channels <= 1) {
            return pcm16;
        }
        int frames = pcm16.length / (2 * channels);
        byte[] out = new byte[frames * 2];
        for (int frame = 0; frame < frames; frame++) {
            int sum = 0;
            for (int channel = 0; channel < channels; channel++) {
                int offset = (frame * channels + channel) * 2;
                sum += (short) ((pcm16[offset] & 0xFF) | (pcm16[offset + 1] << 8));
            }
            int value = sum / channels;
            out[frame * 2] = (byte) value;
            out[frame * 2 + 1] = (byte) (value >> 8);
        }
        return out;
    }

    // ---------------------------------------------------------------- WAV

    private static PcmClip decodeWav(byte[] data) throws IOException {
        if (data.length < 44 || !tag(data, 0, "RIFF") || !tag(data, 8, "WAVE")) {
            throw new IOException("not a RIFF/WAVE file");
        }
        ByteBuffer buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        int position = 12;
        int format = 0;
        int channels = 0;
        int rate = 0;
        int bits = 0;
        int dataOffset = -1;
        int dataLength = 0;
        while (position + 8 <= data.length) {
            String id = new String(data, position, 4, StandardCharsets.US_ASCII);
            long size = buffer.getInt(position + 4) & 0xFFFFFFFFL;
            int body = position + 8;
            if (id.equals("fmt ") && body + 16 <= data.length) {
                format = buffer.getShort(body) & 0xFFFF;
                channels = buffer.getShort(body + 2) & 0xFFFF;
                rate = buffer.getInt(body + 4);
                bits = buffer.getShort(body + 14) & 0xFFFF;
                if (format == 0xFFFE && size >= 26 && body + 26 <= data.length) {
                    format = buffer.getShort(body + 24) & 0xFFFF; // WAVE_FORMAT_EXTENSIBLE sub format
                }
            } else if (id.equals("data")) {
                dataOffset = body;
                dataLength = (int) Math.min(size, (long) data.length - body);
                break;
            }
            long next = body + size + (size & 1L);
            if (next > data.length) {
                break;
            }
            position = (int) next;
        }
        if (dataOffset < 0 || channels < 1 || rate < 1000 || bits < 8 || bits % 8 != 0) {
            throw new IOException("unsupported WAV layout");
        }
        int bytesPerSample = bits / 8;
        int frameSize = bytesPerSample * channels;
        int frames = dataLength / frameSize;
        byte[] out = new byte[frames * 2];
        for (int frame = 0; frame < frames; frame++) {
            double sum = 0.0;
            for (int channel = 0; channel < channels; channel++) {
                sum += readSample(data, dataOffset + frame * frameSize + channel * bytesPerSample, bits, format);
            }
            double mixed = Math.max(-1.0, Math.min(1.0, sum / channels));
            int value = (int) Math.round(mixed * 32767.0);
            out[frame * 2] = (byte) value;
            out[frame * 2 + 1] = (byte) (value >> 8);
        }
        return new PcmClip(out, rate);
    }

    private static boolean tag(byte[] data, int offset, String expected) {
        for (int i = 0; i < expected.length(); i++) {
            if (data[offset + i] != (byte) expected.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    private static double readSample(byte[] d, int o, int bits, int format) throws IOException {
        if (format == 3) { // IEEE float
            if (bits == 32) {
                int raw = (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8) | ((d[o + 2] & 0xFF) << 16) | ((d[o + 3] & 0xFF) << 24);
                return Float.intBitsToFloat(raw);
            }
            if (bits == 64) {
                long raw = 0L;
                for (int i = 7; i >= 0; i--) {
                    raw = (raw << 8) | (d[o + i] & 0xFFL);
                }
                return Double.longBitsToDouble(raw);
            }
            throw new IOException("unsupported float WAV");
        }
        if (format != 1) {
            throw new IOException("unsupported WAV encoding " + format);
        }
        switch (bits) {
            case 8:
                return ((d[o] & 0xFF) - 128) / 128.0;
            case 16:
                return ((short) ((d[o] & 0xFF) | (d[o + 1] << 8))) / 32768.0;
            case 24: {
                int raw = (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8) | (d[o + 2] << 16);
                return raw / 8388608.0;
            }
            case 32: {
                int raw = (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8) | ((d[o + 2] & 0xFF) << 16) | (d[o + 3] << 24);
                return raw / 2147483648.0;
            }
            default:
                throw new IOException("unsupported WAV bit depth " + bits);
        }
    }
}
