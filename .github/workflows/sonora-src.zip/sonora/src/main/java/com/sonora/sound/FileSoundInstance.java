package com.sonora.sound;

import java.util.concurrent.CompletableFuture;

import com.sonora.SonoraClient;
import net.fabricmc.fabric.api.client.sound.v1.FabricSoundInstance;
import net.minecraft.client.sound.AbstractSoundInstance;
import net.minecraft.client.sound.AudioStream;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundLoader;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

/**
 * A one-shot sound whose audio comes from a file in {@code config/sonora/sounds}.
 *
 * <p>The sound event {@code sonora:custom} (see {@code sounds.json}) only exists as a placeholder that
 * is marked as streamed; Fabric API's sound hook then asks this instance for the real audio stream.
 */
public final class FileSoundInstance extends AbstractSoundInstance implements FabricSoundInstance {
    public static final Identifier EVENT_ID = Identifier.of(SonoraClient.MOD_ID, "custom");

    private final String fileName;

    public FileSoundInstance(String fileName, SoundCategory category, float volume, float pitch,
            double x, double y, double z, boolean relative, SoundInstance.AttenuationType attenuation) {
        super(EVENT_ID, category, Random.create());
        this.fileName = fileName;
        this.volume = volume;
        this.pitch = pitch;
        this.x = x;
        this.y = y;
        this.z = z;
        this.relative = relative;
        if (attenuation != null) {
            this.attenuationType = attenuation;
        }
    }

    @Override
    public CompletableFuture<AudioStream> getAudioStream(SoundLoader loader, Identifier id, boolean repeatInstantly) {
        // Decoding can take a moment for long files, so keep it off the render thread.
        return CompletableFuture.supplyAsync(() -> {
            PcmClip clip = CustomAudio.load(fileName);
            return new PcmAudioStream(clip != null ? clip : PcmClip.silence());
        });
    }
}
