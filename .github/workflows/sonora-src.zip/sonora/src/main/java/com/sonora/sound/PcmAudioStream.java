package com.sonora.sound;

import java.nio.ByteBuffer;

import javax.sound.sampled.AudioFormat;

import net.minecraft.client.sound.AudioStream;
import org.lwjgl.BufferUtils;

/** Feeds an already decoded {@link PcmClip} to the game's OpenAL streaming code. */
final class PcmAudioStream implements AudioStream {
    private final byte[] pcm;
    private final AudioFormat format;
    private int position;

    PcmAudioStream(PcmClip clip) {
        this.pcm = clip.pcm();
        this.format = new AudioFormat((float) clip.sampleRate(), 16, 1, true, false);
    }

    @Override
    public AudioFormat getFormat() {
        return format;
    }

    @Override
    public ByteBuffer read(int size) {
        int count = Math.min(size, pcm.length - position);
        if (count < 0) {
            count = 0;
        }
        count -= count % 2; // keep whole 16-bit samples
        // LWJGL needs direct buffers.
        ByteBuffer buffer = BufferUtils.createByteBuffer(count);
        buffer.put(pcm, position, count);
        buffer.flip();
        position += count;
        return buffer;
    }

    @Override
    public void close() {
        // nothing to release
    }
}
