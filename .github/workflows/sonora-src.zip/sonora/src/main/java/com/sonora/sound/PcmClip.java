package com.sonora.sound;

/** Decoded audio: 16-bit signed little-endian mono PCM plus its sample rate. */
public record PcmClip(byte[] pcm, int sampleRate) {
    private static final PcmClip SILENCE = new PcmClip(new byte[2], 44100);

    public static PcmClip silence() {
        return SILENCE;
    }
}
