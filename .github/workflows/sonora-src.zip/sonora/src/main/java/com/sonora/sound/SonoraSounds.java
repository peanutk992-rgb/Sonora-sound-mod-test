package com.sonora.sound;

import com.sonora.SonoraClient;
import com.sonora.config.SonoraConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Helpers to play sounds that are not tied to a position in the world (UI, cues, previews). */
public final class SonoraSounds {
    private SonoraSounds() {
    }

    /** Plays one of the bundled sounds ({@code sonora:<name>}), scaled by the "trigger volume" setting. */
    public static void play(String name, float volume, float pitch) {
        SonoraConfig config = SonoraConfig.get();
        if (!config.enabled) {
            return;
        }
        float scaled = volume * config.triggerVolume;
        if (scaled <= 0.0f) {
            return;
        }
        play(create(Identifier.of(SonoraClient.MOD_ID, name).toString(), scaled, pitch));
    }

    /**
     * Plays a sound event id ({@code minecraft:block.anvil.land}) or a custom file ({@code file:name.wav}).
     * Used by chat triggers and by the preview buttons in the settings screens.
     */
    public static void playTarget(String target, float volume, float pitch) {
        if (target == null || target.isBlank() || volume <= 0.0f) {
            return;
        }
        play(create(target.trim(), volume, pitch));
    }

    private static void play(SoundInstance instance) {
        if (instance != null) {
            MinecraftClient.getInstance().getSoundManager().play(instance);
        }
    }

    private static SoundInstance create(String target, float volume, float pitch) {
        if (target.startsWith("file:")) {
            String name = target.substring("file:".length());
            if (!CustomAudio.exists(name)) {
                return null;
            }
            return new FileSoundInstance(name, SoundCategory.MASTER, volume, pitch, 0.0, 0.0, 0.0, true, null);
        }
        Identifier id = Identifier.tryParse(target);
        if (id == null) {
            return null;
        }
        // Unknown events would only print a warning and stay silent, so skip them.
        if (MinecraftClient.getInstance().getSoundManager().get(id) == null) {
            return null;
        }
        return PositionedSoundInstance.ui(SoundEvent.of(id), pitch, volume);
    }
}
