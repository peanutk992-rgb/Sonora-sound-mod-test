package com.sonora.sound;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

import com.sonora.SonoraClient;
import com.sonora.config.SonoraConfig;
import com.sonora.config.SoundOverride;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

/**
 * The core of the mod. {@link com.sonora.mixin.SoundSystemMixin} calls into this class for every sound
 * the game is about to play:
 * <ul>
 *   <li>{@link #rewrite} swaps one-shot sounds for a replacement (the bundled "style" sounds, a different
 *       vanilla sound, or a custom file) according to the player's settings;</li>
 *   <li>{@link #volumeMultiplier} / {@link #pitchMultiplier} apply the per sound volume, pitch and mute
 *       settings and the underwater muffling.</li>
 * </ul>
 */
public final class SoundRewrite {
    private enum Group {
        UI, COMBAT, ARROW
    }

    /** A built-in replacement. {@code pitch} is NaN when the original pitch should be kept. */
    private record Style(String target, Group group, float volumeScale, float pitch) {
    }

    private static final float UNDERWATER_PITCH = 0.94f;
    private static final Map<String, Style> STYLE = new HashMap<>();

    /** Remembers which sound a replacement stands in for, so its settings follow the original id. */
    private static final Map<SoundInstance, Identifier> ORIGIN = Collections.synchronizedMap(new WeakHashMap<>());

    static {
        style("minecraft:ui.button.click", "ui.click", Group.UI, 1.0f, Float.NaN);
        style("minecraft:entity.player.attack.strong", "combat.hit_strong", Group.COMBAT, 1.0f, Float.NaN);
        style("minecraft:entity.player.attack.weak", "combat.hit_weak", Group.COMBAT, 1.0f, Float.NaN);
        style("minecraft:entity.player.attack.crit", "combat.crit", Group.COMBAT, 1.0f, Float.NaN);
        style("minecraft:entity.player.attack.knockback", "combat.knockback", Group.COMBAT, 1.0f, Float.NaN);
        style("minecraft:entity.player.attack.sweep", "combat.sweep", Group.COMBAT, 1.0f, Float.NaN);
        style("minecraft:entity.player.attack.nodamage", "combat.miss", Group.COMBAT, 1.0f, Float.NaN);
        style("minecraft:entity.arrow.shoot", "bow.release", Group.COMBAT, 1.0f, Float.NaN);
        // The vanilla "arrow hit a player" ping is very quiet and pitched down; use our own level instead.
        style("minecraft:entity.arrow.hit_player", "combat.arrow_ding", Group.ARROW, 3.0f, 1.0f);
    }

    private SoundRewrite() {
    }

    private static void style(String vanillaId, String ownSound, Group group, float volumeScale, float pitch) {
        STYLE.put(vanillaId, new Style(Identifier.of(SonoraClient.MOD_ID, ownSound).toString(), group, volumeScale, pitch));
    }

    private static boolean enabled(Group group, SonoraConfig config) {
        return switch (group) {
            case UI -> config.uiStyle;
            case COMBAT -> config.combatStyle;
            case ARROW -> config.arrowDing;
        };
    }

    // ------------------------------------------------------------------ replacement

    /** Returns the instance that should really be played; the original one when nothing applies. */
    public static SoundInstance rewrite(SoundInstance original) {
        SonoraConfig config = SonoraConfig.get();
        if (original == null || !config.enabled) {
            return original;
        }
        // Only plain one-shot sounds are swapped; looping / tracking / ticking instances are left alone.
        if (original.getClass() != PositionedSoundInstance.class || original.isRepeatable()) {
            return original;
        }

        Identifier id = original.getId();
        String key = id.toString();

        String target = null;
        float volumeScale = 1.0f;
        float fixedPitch = Float.NaN;

        SoundOverride override = config.sounds.get(key);
        if (override != null && override.hasReplacement()) {
            target = override.replace.trim();
        } else {
            Style style = STYLE.get(key);
            if (style != null && enabled(style.group(), config)) {
                target = style.target();
                volumeScale = style.volumeScale();
                fixedPitch = style.pitch();
            }
        }
        if (target == null || target.isEmpty() || target.equals(key)) {
            return original;
        }

        float volume = original.getVolume() * volumeScale;
        float pitch = Float.isNaN(fixedPitch) ? original.getPitch() : fixedPitch;

        SoundInstance replacement = build(original, target, volume, pitch);
        if (replacement == null) {
            return original;
        }
        ORIGIN.put(replacement, id);
        return replacement;
    }

    private static SoundInstance build(SoundInstance original, String target, float volume, float pitch) {
        if (target.startsWith("file:")) {
            String name = target.substring("file:".length());
            if (!CustomAudio.exists(name)) {
                return null;
            }
            return new FileSoundInstance(name, original.getCategory(), volume, pitch,
                    original.getX(), original.getY(), original.getZ(),
                    original.isRelative(), original.getAttenuationType());
        }

        Identifier targetId = Identifier.tryParse(target);
        if (targetId == null) {
            return null;
        }
        // An unknown event would be dropped by the game, so keep the original sound instead.
        if (MinecraftClient.getInstance().getSoundManager().get(targetId) == null) {
            return null;
        }
        SoundEvent event = SoundEvent.of(targetId);
        if (original.isRelative()) {
            return PositionedSoundInstance.ui(event, pitch, volume);
        }
        return new PositionedSoundInstance(event, original.getCategory(), volume, pitch, Random.create(),
                original.getX(), original.getY(), original.getZ());
    }

    // ------------------------------------------------------------------ volume / pitch

    public static float volumeMultiplier(SoundInstance sound) {
        SonoraConfig config = SonoraConfig.get();
        if (!config.enabled) {
            return 1.0f;
        }
        float multiplier = 1.0f;
        SoundOverride override = config.sounds.get(originalId(sound).toString());
        if (override != null) {
            if (override.muted) {
                return 0.0f;
            }
            multiplier *= override.volume;
        }
        if (config.underwaterMuffle && muffled(sound)) {
            multiplier *= config.underwaterVolume;
        }
        return multiplier;
    }

    public static float pitchMultiplier(SoundInstance sound) {
        SonoraConfig config = SonoraConfig.get();
        if (!config.enabled) {
            return 1.0f;
        }
        float multiplier = 1.0f;
        SoundOverride override = config.sounds.get(originalId(sound).toString());
        if (override != null) {
            multiplier *= override.pitch;
        }
        if (config.underwaterMuffle && muffled(sound)) {
            multiplier *= UNDERWATER_PITCH;
        }
        return multiplier;
    }

    private static Identifier originalId(SoundInstance sound) {
        Identifier id = ORIGIN.get(sound);
        return id != null ? id : sound.getId();
    }

    /** True for world sounds heard while the player's eyes are under water. */
    private static boolean muffled(SoundInstance sound) {
        if (sound.isRelative()) {
            return false;
        }
        String category = sound.getCategory().getName();
        if (category.equals("music") || category.equals("record") || category.equals("master")) {
            return false;
        }
        var player = MinecraftClient.getInstance().player;
        return player != null && player.isSubmergedInWater();
    }
}
