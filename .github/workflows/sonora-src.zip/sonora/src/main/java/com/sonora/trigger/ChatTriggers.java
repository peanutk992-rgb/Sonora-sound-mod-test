package com.sonora.trigger;

import java.util.regex.Pattern;

import com.sonora.config.ChatRule;
import com.sonora.config.SonoraConfig;
import com.sonora.sound.SonoraSounds;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

/**
 * Plays a sound when a chat or server message matches one of the {@code chatRules} in the config,
 * for example a "bed destroyed" line on a minigame server.
 */
public final class ChatTriggers {
    private ChatTriggers() {
    }

    public static void register() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) {
                handle(message.getString());
            }
        });
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) ->
                handle(message.getString()));
    }

    private static void handle(String text) {
        SonoraConfig config = SonoraConfig.get();
        if (!config.enabled || !config.chatTriggers || config.chatRules.isEmpty()) {
            return;
        }
        for (ChatRule rule : config.chatRules) {
            Pattern pattern = rule.compiled();
            if (pattern == null || !pattern.matcher(text).find()) {
                continue;
            }
            SonoraSounds.playTarget(rule.sound, rule.volume, rule.pitch);
            if (rule.stop) {
                break;
            }
        }
    }
}
