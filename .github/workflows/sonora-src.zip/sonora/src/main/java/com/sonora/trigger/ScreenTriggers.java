package com.sonora.trigger;

import java.util.Random;

import com.sonora.config.SonoraConfig;
import com.sonora.sound.SonoraSounds;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.client.gui.widget.TextFieldWidget;

/** Typing sounds for every text box (chat, anvil, search fields...). */
public final class ScreenTriggers {
    private static final Random RNG = new Random();

    private ScreenTriggers() {
    }

    public static void register() {
        // Fabric clears the per-screen events whenever a screen is (re)initialised, so subscribe every time.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) ->
                ScreenKeyboardEvents.afterKeyPress(screen).register((current, input) -> {
                    SonoraConfig config = SonoraConfig.get();
                    if (config.enabled && config.uiTyping && current.getFocused() instanceof TextFieldWidget) {
                        SonoraSounds.play("ui.type", 0.55f, 0.94f + RNG.nextFloat() * 0.12f);
                    }
                }));
    }
}
