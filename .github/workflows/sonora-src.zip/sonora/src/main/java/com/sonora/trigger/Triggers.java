package com.sonora.trigger;

import java.util.Random;

import com.sonora.config.SonoraConfig;
import com.sonora.sound.SonoraSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

/**
 * Sounds for things vanilla Minecraft stays silent about. Everything here is driven by a once per tick
 * check of the client state, so no extra hooks into the game are needed.
 */
public final class Triggers {
    private static final Random RNG = new Random();

    // screens
    private static Screen lastScreen;
    private static Object lastHovered;
    private static Screen cursorScreen;
    private static String cursorKey = "";

    // in game
    private static int lastSlot = -1;
    private static boolean lastSneaking;
    private static boolean wasUsingItem;
    private static boolean bowCharged;
    private static int heartbeatCooldown;

    private Triggers() {
    }

    public static void tick(MinecraftClient client) {
        SonoraConfig config = SonoraConfig.get();
        if (!config.enabled) {
            resetWorldState();
            lastScreen = client.currentScreen;
            return;
        }

        tickScreen(client, config);

        var player = client.player;
        if (player == null || client.world == null) {
            resetWorldState();
            return;
        }

        // Hotbar: vanilla has no sound when you change slot.
        int slot = player.getInventory().getSelectedSlot();
        if (config.hotbarSounds && lastSlot != -1 && slot != lastSlot && client.currentScreen == null) {
            SonoraSounds.play("ui.hotbar", 0.7f, varied(1.0f, 0.06f));
        }
        lastSlot = slot;

        // Sneak toggle.
        boolean sneaking = player.isSneaking();
        if (config.sneakSound && sneaking != lastSneaking) {
            SonoraSounds.play("fx.sneak", 0.7f, sneaking ? 0.9f : 1.1f);
        }
        lastSneaking = sneaking;

        // Bow / crossbow draw cue and the "fully drawn" ping.
        boolean using = player.isUsingItem();
        String usedItem = using ? itemPath(player.getActiveItem()) : "";
        if (using && !wasUsingItem) {
            bowCharged = false;
            if (config.bowDraw && (usedItem.equals("bow") || usedItem.equals("crossbow"))) {
                SonoraSounds.play("bow.draw", 0.9f, 1.0f);
            }
        }
        if (using && config.bowCharged && !bowCharged && usedItem.equals("bow") && player.getItemUseTime() >= 20) {
            bowCharged = true;
            SonoraSounds.play("bow.charged", 0.9f, 1.0f);
        }
        if (!using) {
            bowCharged = false;
        }
        wasUsingItem = using;

        // Low health heartbeat.
        float health = player.getHealth();
        if (config.lowHealth && !player.isDead() && health > 0.0f && health <= config.lowHealthThreshold) {
            heartbeatCooldown--;
            if (heartbeatCooldown <= 0) {
                SonoraSounds.play("fx.heartbeat", 0.9f, 1.0f);
                heartbeatCooldown = health <= 2.0f ? 22 : 38;
            }
        } else {
            heartbeatCooldown = 0;
        }
    }

    private static void tickScreen(MinecraftClient client, SonoraConfig config) {
        Screen screen = client.currentScreen;

        // Opening / closing a screen (switching directly between two screens stays silent).
        if (config.uiOpenClose && client.player != null && screen != lastScreen) {
            if (lastScreen == null) {
                SonoraSounds.play("ui.open", 0.8f, 1.0f);
            } else if (screen == null) {
                SonoraSounds.play("ui.close", 0.8f, 1.0f);
            }
        }
        lastScreen = screen;

        // Soft tick when the pointer moves onto a button.
        if (config.uiHover && screen != null) {
            var window = client.getWindow();
            double mouseX = client.mouse.getScaledX(window);
            double mouseY = client.mouse.getScaledY(window);
            Object hovered = screen.hoveredElement(mouseX, mouseY)
                    .filter(element -> element instanceof PressableWidget widget && widget.active)
                    .orElse(null);
            if (hovered != lastHovered) {
                if (hovered != null) {
                    SonoraSounds.play("ui.hover", 0.6f, 1.0f);
                }
                lastHovered = hovered;
            }
        } else {
            lastHovered = null;
        }

        // Picking up / putting down a stack with the cursor in any inventory-like screen.
        if (config.inventorySounds && screen instanceof HandledScreen<?> handled) {
            ItemStack cursor = handled.getScreenHandler().getCursorStack();
            String key = cursor.isEmpty() ? "" : itemId(cursor) + "#" + cursor.getCount();
            if (screen != cursorScreen) {
                cursorScreen = screen;
                cursorKey = key;
            } else if (!key.equals(cursorKey)) {
                SonoraSounds.play(key.isEmpty() ? "ui.slot_place" : "ui.slot_pick", 0.8f, varied(0.97f, 0.05f));
                cursorKey = key;
            }
        } else {
            cursorScreen = null;
        }
    }

    private static void resetWorldState() {
        lastSlot = -1;
        lastSneaking = false;
        wasUsingItem = false;
        bowCharged = false;
        heartbeatCooldown = 0;
    }

    private static String itemId(ItemStack stack) {
        return Registries.ITEM.getId(stack.getItem()).toString();
    }

    private static String itemPath(ItemStack stack) {
        return Registries.ITEM.getId(stack.getItem()).getPath();
    }

    private static float varied(float base, float spread) {
        return base + (RNG.nextFloat() - 0.5f) * 2.0f * spread;
    }
}
