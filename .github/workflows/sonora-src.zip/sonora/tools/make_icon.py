#!/usr/bin/env python3
"""Draws the 128x128 mod icon (speaker with sound waves). Needs Pillow."""
import os

from PIL import Image, ImageDraw

S = 4
W = 128 * S
OUT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "..", "src", "main", "resources", "assets", "sonora", "icon.png"))

grad = Image.new("RGBA", (W, W))
gd = ImageDraw.Draw(grad)
top, bottom = (30, 64, 120), (14, 130, 120)
for y in range(W):
    k = y / (W - 1)
    gd.line([(0, y), (W, y)], fill=tuple(int(top[i] + (bottom[i] - top[i]) * k) for i in range(3)) + (255,))

mask = Image.new("L", (W, W), 0)
ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, W - 1], radius=26 * S, fill=255)
img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
img.paste(grad, (0, 0), mask)

d = ImageDraw.Draw(img)
white = (255, 255, 255, 255)
d.rounded_rectangle([26 * S, 50 * S, 46 * S, 78 * S], radius=3 * S, fill=white)
d.polygon([(44 * S, 50 * S), (70 * S, 32 * S), (70 * S, 96 * S), (44 * S, 78 * S)], fill=white)
cx, cy = 70, 64
for r, alpha in ((20, 255), (33, 205), (46, 150)):
    d.arc([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], -48, 48,
          fill=(255, 255, 255, alpha), width=6 * S)

img.resize((128, 128), Image.LANCZOS).save(OUT)
print("wrote", OUT)
