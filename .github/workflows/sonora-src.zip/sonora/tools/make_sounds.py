#!/usr/bin/env python3
"""Generates every Sonora sound from scratch (additive synthesis + filtered noise).

Needs numpy and ffmpeg (with libvorbis) on PATH.
Run from anywhere:  python3 tools/make_sounds.py
The OGG files land in src/main/resources/assets/sonora/sounds/.
"""
import os
import subprocess
import tempfile
import wave

import numpy as np

SR = 44100
OUT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "..", "src", "main", "resources", "assets", "sonora", "sounds"))
RNG = np.random.default_rng(20261101)


# ------------------------------------------------------------------ building blocks
def tt(dur):
    return np.arange(int(SR * dur)) / SR


def sine(freq, dur):
    return np.sin(2 * np.pi * freq * tt(dur))


def glide(f0, f1, dur):
    """Sine with an exponential frequency glide from f0 to f1."""
    t = tt(dur)
    freq = f0 * (f1 / f0) ** (t / dur)
    return np.sin(2 * np.pi * np.cumsum(freq) / SR)


def noise(dur):
    return RNG.standard_normal(int(SR * dur))


def env(dur, attack, tau):
    """Short linear attack followed by an exponential decay."""
    e = np.exp(-tt(dur) / tau)
    a = int(SR * attack)
    if a > 0:
        e[:a] *= np.linspace(0.0, 1.0, a)
    return e


def band(x, lo, hi):
    """Zero-phase FFT band-pass with soft edges (lo=0 or hi>=Nyquist disables that side)."""
    spec = np.fft.rfft(x)
    f = np.maximum(np.fft.rfftfreq(len(x), 1 / SR), 1e-9)
    mask = np.ones_like(f)
    if lo > 0:
        mask = mask / (1 + (lo / f) ** 6)
    if hi < SR / 2:
        mask = mask / (1 + (f / hi) ** 6)
    return np.fft.irfft(spec * mask, len(x))


def norm(x, peak=1.0):
    m = float(np.max(np.abs(x)))
    return x if m == 0 else x * (peak / m)


def layer(*parts):
    """parts = (offset_seconds, samples, gain); returns the summed signal."""
    end = max(int(SR * off) + len(x) for off, x, _ in parts)
    out = np.zeros(end)
    for off, x, gain in parts:
        i = int(SR * off)
        out[i:i + len(x)] += x * gain
    return out


def whoosh(dur, f0, f1, bands=10):
    """Noise whose pass band glides from f0 to f1 while it swells and fades."""
    n = int(SR * dur)
    pos = np.arange(n) / n
    base = noise(dur)
    out = np.zeros(n)
    for i in range(bands):
        frac = i / (bands - 1)
        fc = f0 * (f1 / f0) ** frac
        out += band(base, fc / 1.6, fc * 1.6) * np.exp(-((pos - frac) ** 2) / (2 * 0.12 ** 2))
    return out * np.sin(np.pi * pos) ** 1.4


def karplus(freq, dur, damping):
    """Plucked string (Karplus-Strong)."""
    n = int(SR * dur)
    period = int(SR / freq)
    buf = RNG.uniform(-1.0, 1.0, period)
    out = np.empty(n)
    for i in range(n):
        j = i % period
        out[i] = buf[j]
        buf[j] = damping * 0.5 * (buf[j] + buf[(j + 1) % period])
    return out


def thump(f0, f1, dur, tau):
    return glide(f0, f1, dur) * env(dur, 0.002, tau)


# ------------------------------------------------------------------ the sounds
def ui_click():
    return layer((0, glide(2300, 1500, 0.07) * env(0.07, 0.001, 0.012), 1.0),
                 (0, band(noise(0.07), 3000, 9000) * env(0.07, 0.0005, 0.002), 0.35))


def ui_hover():
    return sine(2700, 0.04) * env(0.04, 0.002, 0.008)


def ui_open():
    return layer((0, glide(480, 780, 0.13) * env(0.13, 0.008, 0.05), 1.0),
                 (0, glide(960, 1560, 0.13) * env(0.13, 0.008, 0.035), 0.3))


def ui_close():
    return layer((0, glide(780, 470, 0.13) * env(0.13, 0.008, 0.05), 1.0),
                 (0, glide(1560, 940, 0.13) * env(0.13, 0.008, 0.035), 0.3))


def ui_type(freq):
    return layer((0, sine(freq, 0.035) * env(0.035, 0.001, 0.007), 0.9),
                 (0, band(noise(0.035), 2500, 7500) * env(0.035, 0.0005, 0.003), 0.6))


def ui_slot_pick():
    return glide(380, 920, 0.08) * env(0.08, 0.003, 0.03)


def ui_slot_place():
    return layer((0, glide(720, 280, 0.1) * env(0.1, 0.003, 0.04), 1.0),
                 (0, band(noise(0.04), 1500, 6000) * env(0.04, 0.0005, 0.006), 0.3))


def ui_hotbar():
    return layer((0, sine(1250, 0.04) * env(0.04, 0.001, 0.007), 1.0),
                 (0, band(noise(0.03), 2000, 8000) * env(0.03, 0.0005, 0.003), 0.3))


def combat_hit_strong():
    return layer((0, thump(190, 55, 0.2, 0.05), 1.0),
                 (0, sine(95, 0.2) * env(0.2, 0.002, 0.05), 0.45),
                 (0, band(noise(0.14), 700, 4500) * env(0.14, 0.0005, 0.022), 0.7))


def combat_hit_weak():
    return layer((0, thump(300, 120, 0.13, 0.03), 0.9),
                 (0, band(noise(0.09), 1200, 5500) * env(0.09, 0.0005, 0.014), 0.7))


def combat_crit():
    n = 0.55
    ring = (sine(2093, n) * env(n, 0.001, 0.11)
            + 0.5 * sine(3136, n) * env(n, 0.001, 0.07)
            + 0.3 * sine(5588, n) * env(n, 0.001, 0.04))
    return layer((0, combat_hit_strong(), 1.0), (0.012, ring, 0.3))


def combat_knockback():
    return layer((0, thump(170, 45, 0.28, 0.08), 1.0),
                 (0, norm(whoosh(0.34, 520, 170, 8)), 0.8),
                 (0, band(noise(0.1), 500, 3000) * env(0.1, 0.0005, 0.02), 0.5))


def combat_sweep():
    return whoosh(0.3, 500, 3400)


def combat_miss():
    return whoosh(0.17, 700, 2100)


def combat_arrow_ding():
    d = 0.7
    out = np.zeros(int(SR * d))
    for ratio, gain, tau in ((1.0, 1.0, 0.24), (2.0, 0.45, 0.14), (2.76, 0.3, 0.09), (5.4, 0.12, 0.04)):
        out += gain * sine(1568.0 * ratio, d) * env(d, 0.001, tau)
    return out


def bow_draw():
    d = 0.5
    t = tt(d)
    freq = 95 + 75 * (t / d) + 7 * np.sin(2 * np.pi * 23 * t)
    ph = 2 * np.pi * np.cumsum(freq) / SR
    tone = band(np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.33 * np.sin(3 * ph) + 0.25 * np.sin(4 * ph), 150, 1400)
    wob = band(noise(d), 0, 60)
    am = 0.55 + 0.45 * wob / np.max(np.abs(wob))
    grit = norm(band(noise(d), 500, 2500), 0.25)
    swell = np.minimum(1.0, t / 0.05) * np.minimum(1.0, (d - t) / 0.12)
    return (norm(tone) * am + grit) * swell


def bow_charged():
    n = 0.32
    return layer((0, sine(1318.5, n) * env(n, 0.002, 0.07), 0.8),
                 (0.075, sine(1975.5, n) * env(n, 0.002, 0.09), 0.9))


def bow_release():
    twang = band(karplus(130, 0.5, 0.995), 0, 3200)
    thwip = band(noise(0.1), 1500, 6000) * env(0.1, 0.0005, 0.02)
    return layer((0, norm(twang), 0.9), (0, norm(thwip), 0.5))


def fx_heartbeat():
    return layer((0, thump(95, 48, 0.17, 0.05), 1.0),
                 (0, sine(190, 0.17) * env(0.17, 0.002, 0.03), 0.4),
                 (0.17, thump(80, 42, 0.15, 0.045), 0.8),
                 (0.17, sine(160, 0.15) * env(0.15, 0.002, 0.03), 0.3))


def fx_sneak():
    d = 0.14
    return band(noise(d), 900, 4200) * np.sin(np.pi * tt(d) / d) ** 2


# name (path under sounds/, no extension) -> (generator, peak level)
SOUNDS = {
    "ui/click": (ui_click, 0.70),
    "ui/hover": (ui_hover, 0.35),
    "ui/open": (ui_open, 0.55),
    "ui/close": (ui_close, 0.55),
    "ui/type1": (lambda: ui_type(170), 0.50),
    "ui/type2": (lambda: ui_type(205), 0.50),
    "ui/type3": (lambda: ui_type(245), 0.50),
    "ui/slot_pick": (ui_slot_pick, 0.60),
    "ui/slot_place": (ui_slot_place, 0.60),
    "ui/hotbar": (ui_hotbar, 0.45),
    "combat/hit_strong": (combat_hit_strong, 0.90),
    "combat/hit_weak": (combat_hit_weak, 0.75),
    "combat/crit": (combat_crit, 0.90),
    "combat/knockback": (combat_knockback, 0.90),
    "combat/sweep": (combat_sweep, 0.60),
    "combat/miss": (combat_miss, 0.40),
    "combat/arrow_ding": (combat_arrow_ding, 0.85),
    "bow/draw": (bow_draw, 0.60),
    "bow/charged": (bow_charged, 0.70),
    "bow/release": (bow_release, 0.85),
    "fx/heartbeat": (fx_heartbeat, 0.85),
    "fx/sneak": (fx_sneak, 0.40),
}


# ------------------------------------------------------------------ output
def finish(x, peak):
    x = norm(x, peak)
    a = max(1, int(SR * 0.0008))
    b = max(1, int(SR * 0.004))
    x[:a] *= np.linspace(0.0, 1.0, a)
    x[-b:] *= np.linspace(1.0, 0.0, b)
    return x


def encode(rel, x):
    path = os.path.join(OUT, rel + ".ogg")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "in.wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes((np.clip(x, -1.0, 1.0) * 32767).astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1",
                        "-c:a", "libvorbis", "-q:a", "4", path], check=True)
    return path


def main():
    for rel, (fn, peak) in SOUNDS.items():
        x = finish(fn(), peak)
        encode(rel, x)
        print(f"{rel:20s} {len(x) / SR * 1000:6.0f} ms  peak {np.max(np.abs(x)):.2f}")


if __name__ == "__main__":
    main()
